package CSD201_FX01342;
import java.io.PrintWriter;
import java.util.Scanner;

public class DaySo {
    int n;
    int [] a;
    // input method 
    void Nhap(Scanner scanner){
        n = scanner.nextInt();
        a = new int[n];
        for(int i = 0; i<n; i++){
          a[i] = scanner.nextInt();
        }
        ///scanner.close();
    }
    // output method
    void Xuat(){
        try{
            PrintWriter output = new PrintWriter("input.txt");
        for(int i = 0; i<n; i++){
            System.out.print(a[i] + " ");
            output.printf("%d ", a[i]);
        }
        System.out.println("Write to file successfully");
        output.close();
        System.out.println();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    void Display(int []b){
      for(int i = 0; i<n; i++){
            System.out.print(b[i] + " ");
        }
        System.out.println();
        
}
    // swap method
    void Swap(int i,int j, int[]b){   
        // a[i]^=a[j];
        // a[j]^=a[i];
        // a[i]^=a[j];
        int x = b[i]; b[i] = b[j]; b[j] = x;
    }
    void SelectionSort(){
        int min;
        int [] b = new int[n];
        for(int i=0;i<n;i++){
          b[i]= a[i]; 
        }
        try{
            PrintWriter pw = new PrintWriter("output2.txt");
        for(int i = 0; i<n-1; i++){
          min = i;
          for(int j = i+1; j<n; j++){
            if(b[j]<b[min]){
              min = j;
            }
          }
          if(min!=i){
            Swap(min, i,b);
          }
          Display(b);
          for(int k = 0; k<n; k++){
              pw.printf("%d ", b[k]);
          }
          pw.println();
        }
        pw.close();
        System.out.println("Write to file successfully");
    }catch(Exception e){
        e.printStackTrace();
    }
    }
    void BubbleSort(){
        boolean doicho = false;
        int []b = new int[n];
        for(int i=0;i<n;i++){
         b[i]= a[i]; 
        }
        try{
            PrintWriter pw = new PrintWriter("output1.txt");
        for(int i = 0; i<n-1; i++){
            for(int j = 0; j<n-1-i; j++){
                if(b[j]>b[j+1]){
                    Swap(j, j+1, b);
                    doicho = true;
                }
            }
            Display(b);
            for(int k = 0; k<n; k++){
                pw.printf("%d ", b[k]);
            }
            pw.println();
        }
        pw.close();
        System.out.println("Write to file successfully");
    }catch(Exception e){
        e.printStackTrace();
    }
    }
    void InsertionSort(){
        int key, j;
        int []b = new int[n];
        for(int i=0;i<n;i++){
         b[i]= a[i]; 
        }
        try{
            PrintWriter pw = new PrintWriter("output3.txt");
        for(int i = 1; i<n; i++){
            key = a[i];
            j = i-1;
            while((j)>=0  && a[j]>key){
                b[j+1] = b[j];
                j = j-1;
            }
            b[j+1] = key;
            Display(b);
            for(int k = 0; k<n; k++){
                pw.printf("%d ", b[k]);
            }
            pw.println();
        }
        pw.close();
        System.out.println("Write to file successfully");
    }catch(Exception e){
        e.printStackTrace();
    }
    }
    int FindElement(int value){
        int comparison = 0;
        try{
            PrintWriter pw = new PrintWriter("output4.txt");
        for(int i = 0; i<n; i++){
            if(value <= a[i]){
                System.out.println("Vi tri tim thay: " + i + " ");
                comparison++;
                pw.printf("Vi tri tim thay: %d\n", i);
            }
        }
        pw.close();
        System.out.println("Write to file successfully");
    }catch(Exception e){
        e.printStackTrace();
    }
        System.out.println("Total comparison made: " + comparison);
        return comparison;
    }
    
   int BinarySearch(int value){
    int lowerBound = 0;
    int upperBound = n -1;
    int midPoint = -1;
    int comparisons = 0;      
    int index = -1;
    int []b = new int[n];
    for(int i = 0; i<n; i++){
        b[i] = a[i];
    }
    for(int i = 0; i<n; i++){
        for(int j = i+1; j<n; j++){
            if(b[i]>b[j]){
            Swap(i, j, b);
            }
        }
    }
    while(lowerBound <= upperBound) {
       comparisons++;
         
       // compute the mid point
       // midPoint = (lowerBound + upperBound) / 2;
       midPoint = lowerBound + (upperBound - lowerBound) / 2;	
         
       // data found
       if(b[midPoint] == value) {
          index = midPoint;
          break;
       } else {
          // if data is larger 
          if(b[midPoint] < value) {
             // data is in upper half
             lowerBound = midPoint + 1;
          }
          // data is smaller 
          else {
             // data is in lower half 
             upperBound = midPoint -1;
          }
       }               
    }
    System.out.printf("Total comparisons made: %d" , comparisons);
    return index;
   }
}