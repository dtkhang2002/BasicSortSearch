package CSD201_FX01342;
import java.util.Scanner;

public class ASM {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DaySo d = new DaySo();
        int choice;
        while(true){
        Menu();
        choice = scanner.nextInt();
        if(choice == 0){
            System.out.println("Goodbye and have a nice day my friends");
            break;
        }
        switch(choice){ 
            case 1:
                d.Nhap(scanner);
                break;
            case 2:
                d.Xuat();
                break;
            case 3:
                d.SelectionSort();
                break;
            case 4:
                d.BubbleSort();
                break;
            case 5: 
                d.InsertionSort();
                break;
            case 6:
                int value;
                System.out.println("Nhap vao so can tim:");
                value = scanner.nextInt(); 
                int location = d.FindElement(value);
                    if(location != -1){
                        System.out.println("Element found the location");
                    }else{
                        System.out.println("Not found");
                    }
                break;
            case 7:
            System.out.println("Nhap vao so muon tim kiem: ");
                int vl = scanner.nextInt();
                int hud = d.BinarySearch(vl);
                if(hud!=-1){
                    System.out.println("Element found at the location(Binary):" + hud);
                }else{
                    System.out.println("Not Found");
                }
                break;
            default:
                System.out.println("Invalid choice, please try again");
            }
    }   
}
static void Menu(){
    System.out.println("Lua chon cua ban(1,2,3,4,5,6,7,0):");
    System.out.println("1 - Nhap data");
    System.out.println("2 - Xuat data");
    System.out.println("3 - Selection Sort");
    System.out.println("4 - Bubble Sort");
    System.out.println("5 - Inserted Sort");
    System.out.println("6 - Continuous Search");
    System.out.println("7 - Binary search");
    System.out.println("0 - Exit");
}
}
